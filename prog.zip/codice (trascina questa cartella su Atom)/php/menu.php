<?php
header("Expires: on, 01 Jan 1970 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Start the session
if (session_status() === PHP_SESSION_NONE){
  session_start();
  if(!isset($_SESSION["admin"])){
    var_dump("ciao2");
    $_SESSION["admin"]= "false";
    $_SESSION["utente"]= "true";
    $_SESSION["fornitore"]= "false";
  }
  var_dump($_SESSION);
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<a class="navbar-brand" href="homeclienti.php">CFU - Cesena Food University</a>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">

<?php

if ($_SESSION['fornitore']=== "true") {
  var_dump("carico menu fornitore");
  include 'menufornitori.php';
} else {
  if ($_SESSION['admin']=== "true") {
    var_dump("carico menu admin");
    include 'menuadmin.php';
  } else {
    if ($_SESSION['utente']=== "true"){
      var_dump("carico menu utente");
        include 'menuutenti.php';
    }

  }
}

?>

</ul>
</div>
</nav>
